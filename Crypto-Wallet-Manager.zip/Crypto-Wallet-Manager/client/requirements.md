## Packages
ethers | Blockchain interactions (wallet, provider, transactions)
framer-motion | Smooth animations for a premium feel
lucide-react | Icons
zod | Schema validation
react-hook-form | Form handling
@hookform/resolvers | Zod resolver for forms

## Notes
- Using Sepolia testnet for all blockchain operations
- Private keys are stored in React memory ONLY, never sent to backend
- Replit Auth handles user access to the app
- Theme: Modern Dark Crypto (Deep blues, purples, neon accents)
